import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  constructor(public http:HttpClient) { }

  getInventoryData(){
    return this.http.get(environment.server_url+"/inventory");
  }

  addItem(data:any){
    return this.http.post(environment.server_url+"/inventory",data);
  }

  editItem(id:any){
    return this.http.get(environment.server_url+"/inventory/"+id);
  }

  updateItem(data:any){
    return this.http.put(environment.server_url+"/inventory/"+data.id,data);
  }

  deleteItem(id:any){
    return this.http.delete(environment.server_url+"/inventory/"+id);
  }



  

}
