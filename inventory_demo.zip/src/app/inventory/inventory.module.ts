import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InventoryRoutingModule } from './inventory-routing.module';
import { InventoryComponent } from './inventory.component';
import { AddUpdateItemComponent } from './add-update-item/add-update-item.component';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [InventoryComponent, AddUpdateItemComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    InventoryRoutingModule  ]
})
export class InventoryModule { }
