import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { InventoryService } from '../inventory.service';

@Component({
  selector: 'app-add-update-item',
  templateUrl: './add-update-item.component.html',
  styleUrls: ['./add-update-item.component.css']
})
export class AddUpdateItemComponent implements OnInit {
 
  inventoryForm :any = FormGroup;
  submitted = false;
  itemId:any;

  constructor(private activatedRoute: ActivatedRoute,public router:Router,private formBuilder: FormBuilder,public inventoryService:InventoryService) {
    this.activatedRoute.queryParams.subscribe(params => {
      this.itemId = params.id;
    });
   }

  ngOnInit(): void {
    this.inventoryForm = this.formBuilder.group({
      name: ['', Validators.required],
      price: ['', Validators.required],
      id: [''],
      description: ['', Validators.required]
    });

    if(this.itemId){
     this.getItemDataById(this.itemId);
    }
  }

  getItemDataById(id:any){
        this.inventoryService.editItem(id).subscribe(data=>{
            this.inventoryForm.patchValue(data);
        })
  }


// convenience getter for easy access to form fields
get f() { return this.inventoryForm.controls; }

onSubmit() {
    this.submitted = true;

    if (this.inventoryForm.invalid) {
        return;
    } else{
      
      if(this.itemId){
        
        this.inventoryService.updateItem(this.inventoryForm.value).subscribe(data=>{
          alert("data updated suceccfully!!!");
          this.cancel();
      })  
      } else{

        this.inventoryService.addItem(this.inventoryForm.value).subscribe(data=>{
          alert("data added suceccfully!!!");
          this.cancel();
      })
      }      

    }
}


cancel(){
  this.router.navigate(['inventory/invetory-summary']);
}

}
