import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InventoryService } from './inventory.service';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  inventoryData:any =[];
  constructor(public router:Router,public inventoryService:InventoryService) { }

  ngOnInit(): void {
      this.getInventoryDataList();
  }

  getInventoryDataList(){
      this.inventoryService.getInventoryData().subscribe(data=>{
          this.inventoryData = data;
      });
  }

  addItem(){
      this.router.navigate(['inventory/add-update-item']);
  }
  editItem(data:any){
      this.router.navigate(['inventory/add-update-item'],{queryParams:{"id":data.id}});
  }

  deleteItem(data:any){
    if (confirm("Are you sure you want to delete?") == true) {
        this.inventoryService.deleteItem(data.id).subscribe(data=>{
            alert("record delete successfully!!!");
            this.getInventoryDataList();
        })
    }
  }


}
