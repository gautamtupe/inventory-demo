import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUpdateItemComponent } from './add-update-item/add-update-item.component';
import { InventoryComponent } from './inventory.component';

const routes: Routes = [
  {
    path:'invetory-summary',
    component:InventoryComponent
  },
  {
    path:'add-update-item',
    component:AddUpdateItemComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InventoryRoutingModule { }
