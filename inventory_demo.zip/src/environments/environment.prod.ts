export const environment = {
  production: true,
  server_url:"http://localhost:3000"
};
